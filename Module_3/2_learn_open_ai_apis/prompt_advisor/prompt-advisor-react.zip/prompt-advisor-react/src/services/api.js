/**
 * API Service Module
 * Handles all communication with the FastAPI backend
 */

import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000, // 60 seconds for deep analysis
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add API key
apiClient.interceptors.request.use(
  (config) => {
    const apiKey = localStorage.getItem('openai_api_key');
    if (apiKey) {
      config.headers['X-API-Key'] = apiKey;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Server responded with error
      const message = error.response.data?.detail || error.response.statusText;
      throw new Error(message);
    } else if (error.request) {
      // Request made but no response
      throw new Error('No response from server. Please check if the API is running.');
    } else {
      // Something else happened
      throw new Error(error.message);
    }
  }
);

/**
 * API Service Object
 */
const apiService = {
  /**
   * Get API health status
   */
  getHealth: async () => {
    const response = await apiClient.get('/health');
    return response.data;
  },

  /**
   * Get API root information
   */
  getRoot: async () => {
    const response = await apiClient.get('/');
    return response.data;
  },

  /**
   * Get all available templates
   */
  getTemplates: async () => {
    const response = await apiClient.get('/api/v1/templates');
    return response.data;
  },

  /**
   * Get specific template by acronym
   */
  getTemplate: async (acronym) => {
    const response = await apiClient.get(`/api/v1/templates/${acronym}`);
    return response.data;
  },

  /**
   * Get all available techniques
   */
  getTechniques: async () => {
    const response = await apiClient.get('/api/v1/techniques');
    return response.data;
  },

  /**
   * Get specific technique by name (partial match)
   */
  getTechnique: async (name) => {
    const response = await apiClient.get(`/api/v1/techniques/${name}`);
    return response.data;
  },

  /**
   * Analyze business problem
   * @param {string} problem - The business problem to analyze
   * @param {string} mode - Analysis mode ('fast' or 'deep')
   * @param {string} model - OpenAI model to use
   */
  analyzeProblem: async (problem, mode = 'fast', model = 'gpt-4o') => {
    const response = await apiClient.post('/api/v1/analyze', {
      problem,
      mode,
      model,
    });
    return response.data;
  },

  /**
   * Quick analysis (fast mode)
   */
  analyzeFast: async (problem, model = 'gpt-4o') => {
    const response = await apiClient.post('/api/v1/analyze/fast', {
      problem,
      model,
    });
    return response.data;
  },

  /**
   * Deep analysis (deep mode)
   */
  analyzeDeep: async (problem, model = 'gpt-4o') => {
    const response = await apiClient.post('/api/v1/analyze/deep', {
      problem,
      model,
    });
    return response.data;
  },
};

export default apiService;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

// API Configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const App = () => {
  // State management
  const [apiKey, setApiKey] = useState(localStorage.getItem('openai_api_key') || '');
  const [model, setModel] = useState('gpt-4o');
  const [problem, setProblem] = useState('');
  const [mode, setMode] = useState('fast');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [techniques, setTechniques] = useState([]);
  const [healthStatus, setHealthStatus] = useState(null);
  const [selectedExample, setSelectedExample] = useState('Custom');
  const [showSystemPrompt, setShowSystemPrompt] = useState(false);

  // Example problems
  const examples = {
    'Custom': '',
    'E-commerce': 'Build a recommendation system for products based on browsing history and purchases',
    'Chatbot': 'Design a customer service chatbot for telecom billing and support',
    'Marketing': 'Create a sustainable fashion marketing campaign for millennials',
    'Finance': 'Develop a loan risk assessment system with transparent reasoning'
  };

  // Fetch templates and techniques on mount
  useEffect(() => {
    fetchHealthStatus();
    fetchTemplates();
    fetchTechniques();
  }, []);

  // Save API key to localStorage
  useEffect(() => {
    if (apiKey) {
      localStorage.setItem('openai_api_key', apiKey);
    }
  }, [apiKey]);

  // API calls
  const fetchHealthStatus = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/health`);
      setHealthStatus(response.data);
    } catch (err) {
      console.error('Health check failed:', err);
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/v1/templates`);
      setTemplates(response.data.templates || []);
    } catch (err) {
      console.error('Failed to fetch templates:', err);
    }
  };

  const fetchTechniques = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/v1/techniques`);
      setTechniques(response.data.techniques || []);
    } catch (err) {
      console.error('Failed to fetch techniques:', err);
    }
  };

  const handleAnalyze = async () => {
    if (!apiKey) {
      setError('Please provide your OpenAI API key');
      return;
    }

    if (!problem.trim()) {
      setError('Please describe your business problem');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/v1/analyze`,
        {
          problem: problem.trim(),
          mode: mode,
          model: model
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': apiKey
          }
        }
      );

      setResult(response.data);
    } catch (err) {
      const errorMessage = err.response?.data?.detail || err.message || 'Analysis failed';
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setResult(null);
    setError(null);
    setProblem('');
    setSelectedExample('Custom');
  };

  const handleExampleChange = (example) => {
    setSelectedExample(example);
    setProblem(examples[example]);
  };

  const downloadJSON = () => {
    const dataStr = JSON.stringify(result, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = 'recommendation.json';

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const downloadText = () => {
    let textContent = `PROBLEM:\n${problem}\n\n`;
    
    if (result) {
      textContent += `RECOMMENDED TEMPLATE: ${result.recommended_template?.name} (${result.recommended_template?.acronym})\n`;
      textContent += `REASONING: ${result.recommended_template?.reasoning}\n\n`;
      textContent += `RECOMMENDED TECHNIQUE: ${result.recommended_technique?.name}\n`;
      textContent += `REASONING: ${result.recommended_technique?.reasoning}\n\n`;
      
      if (result.example_prompt) {
        textContent += `EXAMPLE PROMPT:\n${result.example_prompt}\n`;
      }
    }

    const dataUri = 'data:text/plain;charset=utf-8,' + encodeURIComponent(textContent);
    const exportFileDefaultName = 'recommendation.txt';

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <div className="app">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <h2>⚙️ Settings</h2>
          {healthStatus && (
            <div className="health-status">
              <span className="status-dot"></span>
              <span className="status-text">API {healthStatus.status}</span>
            </div>
          )}
        </div>

        <div className="settings-section">
          <label>OpenAI API Key</label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="sk-..."
            className="api-key-input"
          />
        </div>

        <div className="settings-section">
          <label>Model</label>
          <select value={model} onChange={(e) => setModel(e.target.value)}>
            <option value="gpt-4o">GPT-4o</option>
            <option value="gpt-4o-mini">GPT-4o Mini</option>
            <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
          </select>
        </div>

        <div className="divider"></div>

        {/* Templates */}
        <details className="expandable-section">
          <summary>📚 Templates ({templates.length})</summary>
          <div className="list-content">
            {templates.map((template, idx) => (
              <div key={idx} className="list-item">
                <strong>{template.acronym}</strong>
                <span>{template.name}</span>
              </div>
            ))}
          </div>
        </details>

        {/* Techniques */}
        <details className="expandable-section">
          <summary>🎯 Techniques ({techniques.length})</summary>
          <div className="list-content">
            {techniques.map((technique, idx) => (
              <div key={idx} className="list-item">
                <strong>{technique.name}</strong>
                <span className="technique-desc">{technique.description}</span>
              </div>
            ))}
          </div>
        </details>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <header className="app-header">
          <h1>🎯 Prompt Advisor</h1>
          <p className="subtitle">AI-powered template and technique recommendations for your business problems</p>
        </header>

        {/* Example Selection */}
        <div className="example-section">
          <label>Choose Example or Write Custom:</label>
          <div className="example-pills">
            {Object.keys(examples).map((example) => (
              <button
                key={example}
                className={`pill ${selectedExample === example ? 'active' : ''}`}
                onClick={() => handleExampleChange(example)}
              >
                {example}
              </button>
            ))}
          </div>
        </div>

        {/* Analysis Mode */}
        <div className="mode-section">
          <label>Analysis Mode:</label>
          <div className="mode-options">
            <button
              className={`mode-btn ${mode === 'fast' ? 'active' : ''}`}
              onClick={() => setMode('fast')}
            >
              <span className="mode-icon">⚡</span>
              <div className="mode-details">
                <strong>Fast</strong>
                <small>Single recommendation (~5 sec, 1 API call)</small>
              </div>
            </button>
            <button
              className={`mode-btn ${mode === 'deep' ? 'active' : ''}`}
              onClick={() => setMode('deep')}
            >
              <span className="mode-icon">🔬</span>
              <div className="mode-details">
                <strong>Deep Analysis</strong>
                <small>Multiple options + LLM Judge (~15 sec, 2 API calls)</small>
              </div>
            </button>
          </div>

          {mode === 'deep' && (
            <div className="info-box">
              <p>🔬 Deep Analysis will:</p>
              <ol>
                <li>Generate 3 different template+technique combinations</li>
                <li>Use LLM as judge to evaluate each on 4 criteria</li>
                <li>Select the best option based on scores</li>
              </ol>
            </div>
          )}
        </div>

        {/* Problem Input */}
        <div className="problem-section">
          <label>Business Problem</label>
          <textarea
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            placeholder="Describe your problem in detail..."
            rows={6}
            className="problem-input"
          />
        </div>

        {/* Action Buttons */}
        <div className="action-buttons">
          <button
            className="btn btn-primary"
            onClick={handleAnalyze}
            disabled={loading || !apiKey || !problem.trim()}
          >
            {loading ? '⏳ Analyzing...' : '🔍 Analyze'}
          </button>
          <button className="btn btn-secondary" onClick={handleClear}>
            🗑️ Clear
          </button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="alert alert-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        {/* Results */}
        {result && !error && (
          <div className="results-container">
            <div className="success-banner">
              ✅ Analysis Complete
            </div>

            {/* Deep Analysis: All Options */}
            {result.mode === 'deep' && result.all_options && (
              <div className="deep-analysis-section">
                <h2>🔬 Deep Analysis: All Options Evaluated</h2>
                
                {result.all_options.map((option, idx) => {
                  const evaluation = result.evaluations?.[idx] || {};
                  const isWinner = result.winner_reasoning?.startsWith(`${idx + 1}`);

                  return (
                    <details key={idx} open={isWinner} className={`option-card ${isWinner ? 'winner' : ''}`}>
                      <summary>
                        {isWinner && '🏆 '}
                        Option {idx + 1}: {option.template.acronym} + {option.technique.name}
                      </summary>
                      
                      <div className="option-content">
                        <div className="option-details">
                          <div className="detail-row">
                            <strong>Template:</strong> {option.template.name}
                          </div>
                          <div className="detail-row">
                            <strong>Technique:</strong> {option.technique.name}
                          </div>
                          <div className="detail-row">
                            <strong>Reasoning:</strong> {option.reasoning}
                          </div>

                          <div className="strengths-weaknesses">
                            <div className="strength-box">
                              <strong>Strengths:</strong>
                              <ul>
                                {option.strengths?.map((s, i) => (
                                  <li key={i}>✅ {s}</li>
                                ))}
                              </ul>
                            </div>
                            <div className="weakness-box">
                              <strong>Weaknesses:</strong>
                              <ul>
                                {option.weaknesses?.map((w, i) => (
                                  <li key={i}>⚠️ {w}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>

                        {evaluation.scores && (
                          <div className="evaluation-scores">
                            <div className="total-score">
                              <div className="score-value">{evaluation.total_score}</div>
                              <div className="score-label">/ 40</div>
                            </div>
                            <div className="score-breakdown">
                              <div className="score-item">
                                <span>Problem Fit:</span>
                                <span>{evaluation.scores.problem_fit}/10</span>
                              </div>
                              <div className="score-item">
                                <span>Clarity:</span>
                                <span>{evaluation.scores.clarity}/10</span>
                              </div>
                              <div className="score-item">
                                <span>Effectiveness:</span>
                                <span>{evaluation.scores.effectiveness}/10</span>
                              </div>
                              <div className="score-item">
                                <span>Flexibility:</span>
                                <span>{evaluation.scores.flexibility}/10</span>
                              </div>
                            </div>
                          </div>
                        )}

                        {evaluation.analysis && (
                          <div className="judge-analysis">
                            <strong>Judge's Analysis:</strong>
                            <p>{evaluation.analysis}</p>
                          </div>
                        )}
                      </div>
                    </details>
                  );
                })}

                {result.winner_reasoning && (
                  <div className="winner-banner">
                    🏆 <strong>Winner Selected:</strong> {result.winner_reasoning}
                  </div>
                )}
              </div>
            )}

            {/* Problem Analysis */}
            <section className="result-section">
              <h2>🔍 Problem Analysis</h2>
              <div className="metrics-grid">
                <div className="metric-card">
                  <div className="metric-label">Complexity</div>
                  <div className="metric-value">{result.problem_analysis?.complexity?.toUpperCase() || 'N/A'}</div>
                </div>
                <div className="metric-card">
                  <div className="metric-label">Creative</div>
                  <div className="metric-value">{result.problem_analysis?.requires_creativity ? '✓' : '✗'}</div>
                </div>
                <div className="metric-card">
                  <div className="metric-label">Data Analysis</div>
                  <div className="metric-value">{result.problem_analysis?.requires_data_analysis ? '✓' : '✗'}</div>
                </div>
                <div className="metric-card">
                  <div className="metric-label">Constraints</div>
                  <div className="metric-value">{result.problem_analysis?.has_constraints ? '✓' : '✗'}</div>
                </div>
              </div>
            </section>

            {/* Recommended Template */}
            <section className="result-section">
              <h2>✨ Recommended Template</h2>
              <div className="recommendation-card">
                <h3>{result.recommended_template?.name} ({result.recommended_template?.acronym})</h3>
                <div className="recommendation-grid">
                  <div>
                    <strong>Why:</strong>
                    <p>{result.recommended_template?.reasoning}</p>
                  </div>
                  <div>
                    <strong>How:</strong>
                    <p>{result.recommended_template?.application}</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Recommended Technique */}
            <section className="result-section">
              <h2>🎯 Recommended Technique</h2>
              <div className="recommendation-card">
                <h3>{result.recommended_technique?.name}</h3>
                <div className="recommendation-grid">
                  <div>
                    <strong>Why:</strong>
                    <p>{result.recommended_technique?.reasoning}</p>
                  </div>
                  <div>
                    <strong>How:</strong>
                    <p>{result.recommended_technique?.application}</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Example Prompt */}
            {result.example_prompt && (
              <section className="result-section">
                <h2>📝 Example Prompt</h2>
                <pre className="code-block">{result.example_prompt}</pre>
              </section>
            )}

            {/* Download Buttons */}
            <div className="download-section">
              <button className="btn btn-download" onClick={downloadJSON}>
                📥 Download JSON
              </button>
              <button className="btn btn-download" onClick={downloadText}>
                📥 Download Text
              </button>
            </div>
          </div>
        )}

        <footer className="app-footer">
          Built with FastAPI, React, and OpenAI GPT-4
        </footer>
      </main>
    </div>
  );
};

export default App;

# 🧪 Testing Guide - Prompt Advisor React App

Comprehensive testing guide for the React frontend.

## Table of Contents
- [Manual Testing](#manual-testing)
- [API Testing](#api-testing)
- [Browser Testing](#browser-testing)
- [Performance Testing](#performance-testing)
- [Accessibility Testing](#accessibility-testing)

---

## 🔍 Manual Testing

### 1. Initial Setup Testing

**Test API Key Input:**
- [ ] Enter valid OpenAI API key
- [ ] Verify key is saved to localStorage
- [ ] Refresh page, verify key persists
- [ ] Clear localStorage, verify key is gone

**Test Model Selection:**
- [ ] Select GPT-4o
- [ ] Select GPT-4o Mini
- [ ] Select GPT-3.5 Turbo
- [ ] Verify selection persists

**Test Health Check:**
- [ ] Green status indicator when API is running
- [ ] Shows "API healthy" text
- [ ] Displays template and technique counts

---

### 2. Example Selection Testing

**Test Each Example:**
- [ ] Click "Custom" - textarea should be empty
- [ ] Click "E-commerce" - correct text appears
- [ ] Click "Chatbot" - correct text appears
- [ ] Click "Marketing" - correct text appears
- [ ] Click "Finance" - correct text appears
- [ ] Active pill shows correct styling

---

### 3. Analysis Mode Testing

**Fast Mode:**
- [ ] Select Fast mode
- [ ] Button shows "⚡ Fast"
- [ ] No info box appears
- [ ] Analysis completes in ~5 seconds
- [ ] Shows single recommendation

**Deep Mode:**
- [ ] Select Deep mode
- [ ] Button shows "🔬 Deep Analysis"
- [ ] Info box appears with 3 steps
- [ ] Analysis completes in ~15 seconds
- [ ] Shows 3 options with evaluations
- [ ] Winner is highlighted

---

### 4. Problem Input Testing

**Test Input:**
- [ ] Type custom problem
- [ ] Textarea expands properly
- [ ] Can paste text
- [ ] Unicode characters work
- [ ] Very long text works (1000+ chars)

**Test Validation:**
- [ ] Empty input - analyze button disabled
- [ ] With input - analyze button enabled
- [ ] API key required - shows error if missing

---

### 5. Analysis Results Testing

**Fast Mode Results:**
- [ ] Success banner appears
- [ ] Problem analysis metrics shown (4 cards)
- [ ] Recommended template displayed
- [ ] Template reasoning provided
- [ ] Template application steps provided
- [ ] Recommended technique displayed
- [ ] Technique reasoning provided
- [ ] Technique application steps provided
- [ ] Example prompt shown

**Deep Mode Results:**
- [ ] All 3 options displayed
- [ ] Each option has:
  - [ ] Template + Technique names
  - [ ] Reasoning
  - [ ] Strengths (with ✅)
  - [ ] Weaknesses (with ⚠️)
  - [ ] Scores (out of 40)
  - [ ] Score breakdown (4 metrics)
  - [ ] Judge's analysis
- [ ] Winner option highlighted (🏆)
- [ ] Winner reasoning displayed
- [ ] Same structure as fast mode after options

---

### 6. Download Functionality Testing

**JSON Download:**
- [ ] Click "Download JSON"
- [ ] File downloads
- [ ] File name is "recommendation.json"
- [ ] Content is valid JSON
- [ ] Contains all result data

**Text Download:**
- [ ] Click "Download Text"
- [ ] File downloads
- [ ] File name is "recommendation.txt"
- [ ] Contains formatted recommendation
- [ ] Readable format

---

### 7. Error Handling Testing

**Test Error Scenarios:**
- [ ] No API key - shows error message
- [ ] Invalid API key - shows error from backend
- [ ] Backend not running - shows connection error
- [ ] Network timeout - shows timeout error
- [ ] Invalid problem (too short) - shows validation error

**Error Message Display:**
- [ ] Error alert appears
- [ ] Red styling applied
- [ ] Clear error message
- [ ] Error doesn't crash app

---

### 8. UI/UX Testing

**Sidebar:**
- [ ] Scrolls independently
- [ ] Settings section clear
- [ ] Templates expandable works
- [ ] Techniques expandable works
- [ ] Lists show all items
- [ ] Health status updates

**Main Content:**
- [ ] Header displays correctly
- [ ] Subtitle readable
- [ ] All sections aligned
- [ ] Spacing consistent
- [ ] Colors match theme

**Animations:**
- [ ] Page load animation smooth
- [ ] Button hover effects work
- [ ] Card hover effects work
- [ ] Transitions smooth
- [ ] Loading spinner visible

---

## 🌐 API Testing

### Using cURL

**Health Check:**
```bash
curl http://localhost:8000/health
```

**Get Templates:**
```bash
curl http://localhost:8000/api/v1/templates
```

**Fast Analysis:**
```bash
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-key-here" \
  -d '{
    "problem": "Test problem",
    "mode": "fast"
  }'
```

**Deep Analysis:**
```bash
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-key-here" \
  -d '{
    "problem": "Test problem",
    "mode": "deep"
  }'
```

### Using Postman

Import the collection:
1. Create new collection "Prompt Advisor"
2. Add variable `base_url`: `http://localhost:8000`
3. Add variable `api_key`: Your OpenAI key
4. Add requests from API documentation

---

## 🖥️ Browser Testing

### Desktop Browsers

**Chrome:**
- [ ] Layout correct
- [ ] All features work
- [ ] Console has no errors
- [ ] Network requests succeed

**Firefox:**
- [ ] Layout correct
- [ ] All features work
- [ ] Console has no errors
- [ ] Network requests succeed

**Safari:**
- [ ] Layout correct
- [ ] All features work
- [ ] Console has no errors
- [ ] Network requests succeed

**Edge:**
- [ ] Layout correct
- [ ] All features work
- [ ] Console has no errors
- [ ] Network requests succeed

### Mobile Browsers

**iOS Safari:**
- [ ] Responsive layout
- [ ] Touch interactions work
- [ ] Scrolling smooth
- [ ] Inputs functional

**Android Chrome:**
- [ ] Responsive layout
- [ ] Touch interactions work
- [ ] Scrolling smooth
- [ ] Inputs functional

### Responsive Design

**Desktop (1920x1080):**
- [ ] Two-column layout
- [ ] Sidebar visible
- [ ] Content centered
- [ ] No horizontal scroll

**Tablet (768x1024):**
- [ ] Single-column layout
- [ ] Sidebar on top
- [ ] Content full width
- [ ] Touch-friendly

**Mobile (375x667):**
- [ ] Single-column layout
- [ ] Sidebar on top
- [ ] Buttons stacked
- [ ] Text readable
- [ ] No horizontal scroll

---

## ⚡ Performance Testing

### Lighthouse Audit

```bash
# Install Lighthouse
npm install -g lighthouse

# Run audit
lighthouse http://localhost:3000 --view
```

**Target Scores:**
- [ ] Performance: 90+
- [ ] Accessibility: 90+
- [ ] Best Practices: 90+
- [ ] SEO: 90+

### Load Time Testing

**Metrics to Check:**
- [ ] First Contentful Paint (FCP) < 1.8s
- [ ] Largest Contentful Paint (LCP) < 2.5s
- [ ] Time to Interactive (TTI) < 3.8s
- [ ] Total Blocking Time (TBT) < 200ms
- [ ] Cumulative Layout Shift (CLS) < 0.1

### Network Testing

**Test Different Speeds:**
- [ ] Fast 4G - acceptable performance
- [ ] Slow 3G - degraded but functional
- [ ] Offline - shows error message

---

## ♿ Accessibility Testing

### Keyboard Navigation

- [ ] Tab through all interactive elements
- [ ] Focus indicators visible
- [ ] Enter/Space activates buttons
- [ ] Escape closes modals/expandables
- [ ] No keyboard traps

### Screen Reader Testing

**Using NVDA/JAWS/VoiceOver:**
- [ ] All headings announced
- [ ] All buttons labeled
- [ ] All inputs labeled
- [ ] All images have alt text
- [ ] Landmarks properly defined

### Color Contrast

**Check WCAG AA compliance:**
- [ ] Text on backgrounds: 4.5:1 minimum
- [ ] Large text: 3:1 minimum
- [ ] Interactive elements visible
- [ ] Error messages clear

### Testing Tools

```bash
# Install axe-core
npm install -D @axe-core/react

# Add to main.jsx (development only)
if (process.env.NODE_ENV !== 'production') {
  import('@axe-core/react').then(axe => {
    axe.default(React, ReactDOM, 1000);
  });
}
```

---

## 🐛 Debugging

### Browser DevTools

**Console Tab:**
- Check for JavaScript errors
- Verify API responses
- Monitor state changes

**Network Tab:**
- Verify API calls
- Check request headers (X-API-Key)
- Monitor response times
- Check for failed requests

**React DevTools:**
- Inspect component tree
- Monitor state changes
- Track re-renders
- Profile performance

### Common Issues

**API Not Responding:**
```bash
# Check if backend is running
curl http://localhost:8000/health

# Check CORS
curl -H "Origin: http://localhost:3000" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: X-API-Key" \
  -X OPTIONS http://localhost:8000/api/v1/analyze
```

**State Not Updating:**
- Check React DevTools
- Verify useState/useEffect hooks
- Check for missing dependencies

**Styling Issues:**
- Inspect element in DevTools
- Check CSS specificity
- Verify CSS variables
- Check responsive breakpoints

---

## ✅ Pre-Release Checklist

### Functional Testing
- [ ] All API endpoints work
- [ ] All examples load
- [ ] Both analysis modes work
- [ ] Downloads work
- [ ] Error handling works
- [ ] API key persistence works

### Cross-Browser Testing
- [ ] Chrome ✓
- [ ] Firefox ✓
- [ ] Safari ✓
- [ ] Edge ✓
- [ ] Mobile browsers ✓

### Performance Testing
- [ ] Lighthouse scores 90+
- [ ] Load time < 3s
- [ ] No console errors
- [ ] No memory leaks

### Accessibility Testing
- [ ] Keyboard navigation ✓
- [ ] Screen reader compatible ✓
- [ ] Color contrast WCAG AA ✓
- [ ] Focus indicators visible ✓

### Security Testing
- [ ] API key not exposed
- [ ] HTTPS in production
- [ ] No XSS vulnerabilities
- [ ] CORS configured properly

---

## 📊 Test Reports

### Create Test Log

```markdown
# Test Report - [Date]

## Environment
- React: 18.2.0
- Node: 18.x
- Browser: Chrome 120
- OS: macOS 14

## Test Results

### Functional Tests
- API Integration: ✅ Pass
- User Input: ✅ Pass
- Error Handling: ✅ Pass
- Downloads: ✅ Pass

### Performance Tests
- Lighthouse Performance: 95/100
- Load Time: 2.1s
- Bundle Size: 245 KB

### Accessibility Tests
- WCAG AA: ✅ Pass
- Keyboard Nav: ✅ Pass
- Screen Reader: ✅ Pass

## Issues Found
1. None

## Recommendations
1. Consider code splitting for larger bundles
2. Add more error recovery options
```

---

**Testing ensures quality! 🎯**

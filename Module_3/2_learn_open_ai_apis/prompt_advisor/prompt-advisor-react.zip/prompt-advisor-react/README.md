# 🎯 Prompt Advisor - React Frontend

Modern, production-ready React frontend for the Prompt Advisor API. Get AI-powered template and technique recommendations for your business problems.

![React](https://img.shields.io/badge/React-18.2-61DAFB?logo=react)
![Vite](https://img.shields.io/badge/Vite-5.0-646CFF?logo=vite)
![Axios](https://img.shields.io/badge/Axios-1.6-5A29E4)

## ✨ Features

- **🎨 Modern UI/UX**: Distinctive design with gradient themes, smooth animations, and responsive layout
- **⚡ Fast Mode**: Quick single recommendation in ~5 seconds
- **🔬 Deep Analysis Mode**: Multiple options evaluated by LLM judge (~15 seconds)
- **📊 Real-time Analysis**: Live problem complexity assessment
- **💾 Export Results**: Download recommendations as JSON or text
- **🔒 Secure**: API key stored locally in browser
- **📱 Responsive**: Works seamlessly on desktop, tablet, and mobile

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm/yarn
- FastAPI backend running on `http://localhost:8000`
- OpenAI API key

### Installation

```bash
# Clone or navigate to the project directory
cd prompt-advisor-react

# Install dependencies
npm install

# Create environment file (optional)
cp .env.example .env

# Start development server
npm run dev
```

The app will be available at `http://localhost:3000`

### Backend Setup

Make sure the FastAPI backend is running:

```bash
# In a separate terminal
uvicorn api:app --reload
```

## 📁 Project Structure

```
prompt-advisor-react/
├── src/
│   ├── App.jsx          # Main application component
│   ├── App.css          # Comprehensive styling
│   └── main.jsx         # React entry point
├── index.html           # HTML template
├── vite.config.js       # Vite configuration
├── package.json         # Dependencies
└── README.md           # This file
```

## 🎯 How It Works

### 1. **API Integration**

The React app communicates with the FastAPI backend using axios:

```javascript
// Fast Analysis
POST /api/v1/analyze
{
  "problem": "Your business problem",
  "mode": "fast",
  "model": "gpt-4o"
}

// Deep Analysis
POST /api/v1/analyze
{
  "problem": "Your business problem",
  "mode": "deep",
  "model": "gpt-4o"
}
```

### 2. **Authentication**

API key is sent via HTTP header:
```javascript
headers: {
  'X-API-Key': 'your-openai-api-key'
}
```

### 3. **State Management**

React hooks manage application state:
- `useState` for component state
- `useEffect` for data fetching
- `localStorage` for API key persistence

## 🔧 Configuration

### Environment Variables

Create a `.env` file:

```env
REACT_APP_API_URL=http://localhost:8000
```

### API Base URL

Change the API endpoint in `App.jsx`:

```javascript
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';
```

## 🎨 Design Features

### Typography
- **Display Font**: Syne (bold, modern)
- **Body Font**: DM Sans (clean, readable)

### Color Scheme
- **Primary**: Deep Purple (#6366f1)
- **Accent**: Amber (#f59e0b)
- **Background**: Dark theme with gradient effects

### Animations
- Smooth transitions (250ms cubic-bezier)
- Floating background gradients
- Hover effects and micro-interactions
- Loading spinners

## 📊 Components Breakdown

### Sidebar
- **Settings**: API key input, model selection
- **Health Status**: Live API status indicator
- **Templates List**: All available templates (10)
- **Techniques List**: All available techniques (7)

### Main Content
- **Example Selection**: Pre-defined problem examples
- **Mode Selection**: Fast vs Deep analysis
- **Problem Input**: Textarea for custom problems
- **Results Display**: Dynamic rendering based on mode

### Results Components
- **Problem Analysis**: Complexity metrics
- **Template Recommendation**: With reasoning and application
- **Technique Recommendation**: With reasoning and application
- **Example Prompt**: Generated prompt preview
- **Deep Analysis**: All options with scores (deep mode only)

## 🚢 Deployment

### Build for Production

```bash
npm run build
```

This creates an optimized build in the `dist/` directory.

### Deployment Options

#### 1. **Vercel** (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

#### 2. **Netlify**

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Build and deploy
npm run build
netlify deploy --prod --dir=dist
```

#### 3. **Docker**

```dockerfile
FROM node:18-alpine AS build

WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Build and run:
```bash
docker build -t prompt-advisor-react .
docker run -p 80:80 prompt-advisor-react
```

#### 4. **Static Hosting** (S3, GitHub Pages, etc.)

Simply upload the contents of `dist/` to your static hosting provider.

### Environment Variables in Production

Set these in your hosting platform:
- `REACT_APP_API_URL`: Your production API URL

## 🔐 Security Best Practices

1. **Never commit API keys**: Use environment variables
2. **Use HTTPS**: Always in production
3. **CORS Configuration**: Configure backend CORS properly
4. **Rate Limiting**: Implement on backend
5. **Input Validation**: Sanitize user inputs

## 🧪 Testing

```bash
# Run in development mode
npm run dev

# Build and preview production build
npm run build
npm run preview
```

### Test Cases

1. **API Connection**: Health check on load
2. **Fast Analysis**: Test with example problems
3. **Deep Analysis**: Verify 3 options + evaluation
4. **Error Handling**: Test with invalid API key
5. **Responsive Design**: Test on different screen sizes
6. **Download Features**: Verify JSON and text exports

## 📝 API Endpoints Used

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Check API status |
| `/api/v1/templates` | GET | Fetch all templates |
| `/api/v1/techniques` | GET | Fetch all techniques |
| `/api/v1/analyze` | POST | Analyze problem (fast/deep) |

## 🛠️ Development

### Running Development Server

```bash
npm run dev
```

Features:
- Hot Module Replacement (HMR)
- Fast refresh
- Source maps
- Proxy to backend API

### Project Scripts

```json
{
  "dev": "vite",           // Start dev server
  "build": "vite build",   // Production build
  "preview": "vite preview" // Preview production build
}
```

## 🐛 Troubleshooting

### CORS Errors

If you see CORS errors, ensure backend has proper CORS configuration:

```python
# In FastAPI backend
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### API Connection Failed

1. Verify backend is running: `http://localhost:8000/health`
2. Check `REACT_APP_API_URL` in `.env`
3. Verify network connectivity
4. Check browser console for errors

### Build Errors

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Clear Vite cache
rm -rf node_modules/.vite
```

## 📚 Resources

- [React Documentation](https://react.dev)
- [Vite Documentation](https://vitejs.dev)
- [Axios Documentation](https://axios-http.com)
- [FastAPI Documentation](https://fastapi.tiangolo.com)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- Built with React 18 and Vite
- Powered by OpenAI GPT-4
- Backend by FastAPI
- Icons from Unicode emoji
- Fonts from Google Fonts

---

**Ready to get AI-powered prompt recommendations! 🎯**

For questions or issues, please check the backend API documentation.

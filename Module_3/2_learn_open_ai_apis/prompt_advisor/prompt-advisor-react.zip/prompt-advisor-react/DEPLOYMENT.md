# 🚀 Deployment Guide - Prompt Advisor React App

Complete guide for deploying the React frontend to various platforms.

## Table of Contents
- [Local Development](#local-development)
- [Production Build](#production-build)
- [Docker Deployment](#docker-deployment)
- [Cloud Platforms](#cloud-platforms)
- [Environment Configuration](#environment-configuration)

---

## 🏠 Local Development

### Setup
```bash
# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Start development server
npm run dev
```

Development server runs at: `http://localhost:3000`

**Important**: Ensure FastAPI backend is running at `http://localhost:8000`

---

## 📦 Production Build

### Build Process
```bash
# Create optimized production build
npm run build

# Preview production build locally
npm run preview
```

The `dist/` folder contains the production-ready static files.

### Build Optimization
- Minified JavaScript and CSS
- Code splitting for faster loads
- Tree shaking to remove unused code
- Asset optimization (images, fonts)

---

## 🐳 Docker Deployment

### Option 1: Frontend Only

```bash
# Build image
docker build -t prompt-advisor-frontend .

# Run container
docker run -p 80:80 prompt-advisor-frontend
```

Access at: `http://localhost`

### Option 2: Full Stack (Frontend + Backend)

```bash
# Create .env file with OpenAI key
echo "OPENAI_API_KEY=sk-your-key-here" > .env

# Start both services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

**Services:**
- Frontend: `http://localhost`
- Backend: `http://localhost:8000`
- API Docs: `http://localhost:8000/docs`

---

## ☁️ Cloud Platforms

### 1. Vercel (Recommended for Frontend)

**Automatic Deployment:**

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Configure:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Environment Variables:
     - `REACT_APP_API_URL`: Your backend API URL

**CLI Deployment:**

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

**Environment Variables in Vercel:**
```bash
vercel env add REACT_APP_API_URL production
# Enter your production API URL (e.g., https://api.yourapp.com)
```

---

### 2. Netlify

**Automatic Deployment:**

1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Connect repository
4. Configure:
   - Build Command: `npm run build`
   - Publish Directory: `dist`
   - Environment Variables: Add `REACT_APP_API_URL`

**CLI Deployment:**

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Login
netlify login

# Initialize
netlify init

# Deploy
netlify deploy

# Deploy to production
netlify deploy --prod
```

**Create `netlify.toml`:**
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[build.environment]
  REACT_APP_API_URL = "https://your-api-url.com"
```

---

### 3. AWS S3 + CloudFront

**Setup:**

```bash
# Build the app
npm run build

# Install AWS CLI
pip install awscli

# Configure AWS credentials
aws configure

# Create S3 bucket
aws s3 mb s3://prompt-advisor-app

# Enable static website hosting
aws s3 website s3://prompt-advisor-app \
  --index-document index.html \
  --error-document index.html

# Upload files
aws s3 sync dist/ s3://prompt-advisor-app --delete

# Make bucket public (for CloudFront)
aws s3api put-bucket-policy \
  --bucket prompt-advisor-app \
  --policy file://bucket-policy.json
```

**bucket-policy.json:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::prompt-advisor-app/*"
    }
  ]
}
```

**CloudFront Distribution:**
1. Create distribution in AWS Console
2. Set S3 bucket as origin
3. Configure custom error responses (404 → /index.html)
4. Add SSL certificate
5. Update DNS records

---

### 4. Google Cloud Storage + Load Balancer

```bash
# Build app
npm run build

# Create bucket
gsutil mb gs://prompt-advisor-app

# Upload files
gsutil -m rsync -r dist/ gs://prompt-advisor-app

# Make bucket public
gsutil iam ch allUsers:objectViewer gs://prompt-advisor-app

# Set website configuration
gsutil web set -m index.html -e index.html gs://prompt-advisor-app
```

---

### 5. Azure Static Web Apps

```bash
# Install Azure CLI
npm i -g @azure/static-web-apps-cli

# Login
az login

# Deploy
swa deploy
```

**Or use GitHub Actions:**

Create `.github/workflows/azure-static-web-apps.yml`:
```yaml
name: Azure Static Web Apps CI/CD

on:
  push:
    branches:
      - main

jobs:
  build_and_deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build And Deploy
        uses: Azure/static-web-apps-deploy@v1
        with:
          azure_static_web_apps_api_token: ${{ secrets.AZURE_STATIC_WEB_APPS_API_TOKEN }}
          repo_token: ${{ secrets.GITHUB_TOKEN }}
          action: "upload"
          app_location: "/"
          api_location: ""
          output_location: "dist"
```

---

### 6. DigitalOcean App Platform

1. Push code to GitHub
2. Go to [DigitalOcean](https://cloud.digitalocean.com)
3. Create new App
4. Connect repository
5. Configure:
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Environment Variables: `REACT_APP_API_URL`

---

## 🔧 Environment Configuration

### Development (.env.local)
```env
REACT_APP_API_URL=http://localhost:8000
```

### Staging (.env.staging)
```env
REACT_APP_API_URL=https://staging-api.yourapp.com
```

### Production (.env.production)
```env
REACT_APP_API_URL=https://api.yourapp.com
```

### Using Different Environments

```bash
# Development
npm run dev

# Production build
npm run build

# Custom environment
REACT_APP_API_URL=https://custom.api.com npm run build
```

---

## 🔐 Backend Deployment Considerations

### CORS Configuration

Ensure your FastAPI backend allows requests from your frontend domain:

```python
from fastapi.middleware.cors import CORSMiddleware

origins = [
    "http://localhost:3000",           # Development
    "https://yourapp.vercel.app",      # Vercel
    "https://yourapp.netlify.app",     # Netlify
    "https://yourapp.com",             # Production
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### Backend Deployment Options

1. **Heroku**: Easy deployment with `Procfile`
2. **Railway**: Modern platform with automatic deployments
3. **Render**: Simple deployment from GitHub
4. **AWS Elastic Beanstalk**: Scalable, managed service
5. **Google Cloud Run**: Serverless container deployment
6. **DigitalOcean App Platform**: Simple container deployment

---

## 📊 Monitoring & Analytics

### Add Google Analytics

```html
<!-- Add to index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Error Tracking with Sentry

```bash
npm install @sentry/react
```

```javascript
// In main.jsx
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "your-sentry-dsn",
  environment: process.env.NODE_ENV,
});
```

---

## ✅ Pre-Deployment Checklist

- [ ] Run `npm run build` successfully
- [ ] Test production build locally (`npm run preview`)
- [ ] Configure environment variables
- [ ] Set up CORS on backend
- [ ] Test API connectivity
- [ ] Enable HTTPS/SSL
- [ ] Configure custom domain (optional)
- [ ] Set up monitoring/analytics
- [ ] Test on multiple browsers
- [ ] Test responsive design
- [ ] Optimize performance (Lighthouse score)
- [ ] Set up error tracking

---

## 🚨 Troubleshooting

### Build Fails
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### API Connection Issues
- Check `REACT_APP_API_URL` is correct
- Verify CORS settings on backend
- Check network tab in browser DevTools
- Ensure backend is accessible from frontend URL

### Blank Page After Deployment
- Check browser console for errors
- Verify all assets are being served correctly
- Check routing configuration
- Ensure `index.html` is served for all routes

---

## 📚 Additional Resources

- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html)
- [React Deployment Docs](https://react.dev/learn/start-a-new-react-project#deploying-a-react-app)
- [Nginx Configuration Guide](https://www.nginx.com/resources/wiki/start/)

---

**Your app is ready for deployment! 🚀**

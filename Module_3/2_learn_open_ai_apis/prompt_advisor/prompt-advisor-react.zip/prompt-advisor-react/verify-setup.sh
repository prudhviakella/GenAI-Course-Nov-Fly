#!/bin/bash

# Prompt Advisor React - Setup Verification Script

echo "🎯 Prompt Advisor React - Setup Verification"
echo "=============================================="
echo ""

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check counter
checks_passed=0
checks_failed=0

# Function to check file exists
check_file() {
    if [ -f "$1" ]; then
        echo -e "${GREEN}✓${NC} $1"
        ((checks_passed++))
    else
        echo -e "${RED}✗${NC} $1 (MISSING)"
        ((checks_failed++))
    fi
}

# Function to check directory exists
check_dir() {
    if [ -d "$1" ]; then
        echo -e "${GREEN}✓${NC} $1/"
        ((checks_passed++))
    else
        echo -e "${RED}✗${NC} $1/ (MISSING)"
        ((checks_failed++))
    fi
}

echo "📁 Checking Project Structure..."
echo ""

echo "Configuration Files:"
check_file "package.json"
check_file "vite.config.js"
check_file ".env.example"
check_file ".gitignore"
echo ""

echo "HTML & Entry:"
check_file "index.html"
echo ""

echo "Source Code:"
check_dir "src"
check_file "src/main.jsx"
check_file "src/App.jsx"
check_file "src/App.css"
check_dir "src/services"
check_file "src/services/api.js"
echo ""

echo "Docker & Deployment:"
check_file "Dockerfile"
check_file "docker-compose.yml"
check_file "nginx.conf"
echo ""

echo "Documentation:"
check_file "README.md"
check_file "DEPLOYMENT.md"
check_file "TESTING.md"
check_file "PROJECT_SUMMARY.md"
check_file "FILE_TREE.md"
echo ""

echo "=============================================="
echo -e "Results: ${GREEN}$checks_passed passed${NC}, ${RED}$checks_failed failed${NC}"
echo ""

if [ $checks_failed -eq 0 ]; then
    echo -e "${GREEN}✓ All files present! Ready to start.${NC}"
    echo ""
    echo "Next steps:"
    echo "1. npm install"
    echo "2. cp .env.example .env (and configure)"
    echo "3. npm run dev"
    echo ""
    exit 0
else
    echo -e "${RED}✗ Some files are missing!${NC}"
    echo "Please ensure all files are properly copied."
    echo ""
    exit 1
fi
